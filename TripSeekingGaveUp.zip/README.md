# TripSeeking
 Exam answer for exam at Binus, Human Computer Interactions
 
## Source Code Location
https://github.com/JOELwindows7/TripSeeking

GitHub location will open after the exam score released

## Hidden Creativities
- Click on top right navigation tool. **the blue rectangle behind the navigation text moves as you went into the pages**
- index.html contains only the top header and about us info. the middle div is iFrame which page can be changed using Top right nav button
- Turns out this is bad idea because browsers doesn't support cross domain iframe access ( https://stackoverflow.com/questions/1451208/access-iframe-elements-in-javascript ) due to security reason
- The Logged in situation should show user profile picture and email name next to it. but due to browser restrictions, it's all ruined.
